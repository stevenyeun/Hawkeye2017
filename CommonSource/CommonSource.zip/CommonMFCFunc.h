#pragma once
class CCommonMFCFunc
{
public:
	CCommonMFCFunc();
	~CCommonMFCFunc();

	static void HideIconFromTaskbar();
	static void AutoHideTaskbar();
};

